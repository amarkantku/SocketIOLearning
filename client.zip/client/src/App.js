import { io } from "socket.io-client";
import React, {useState, useEffect} from 'react';
import './App.css';
let socket = null;
function App() {


  const [count, setCount] = useState(0); 

  useEffect(() => {
    socket = io('ws://localhost:3001');
    
    socket.on('counter updated', function(data) {
      console.log('counter value from server', data);
      setCount(data);
    });
    return () => socket.disconnect();
  }, []);

  function handleClick() {
    socket.emit('counter clicked');
  }

  return (
    <div className="App">
      <header className="App-header">
        <div>Welcome to the socket.io</div>
        <div>
        Test data from server: {count}
        <br></br>
        <button onClick={handleClick}>Click</button>
      </div>
      </header>
     
    </div>
  );
}

export default App;
